// =========================================================================================
// 🚀 市場趨勢監測系統 - popup.js v6.3 (優化 3 日預設區間與外鏈相容性)
// =========================================================================================

// ⚠️ 請填入你的 Google Apps Script Web App 部署網址 (EXEC 網址)
const GAS_WEB_APP_URL = "https://script.google.com/a/macros/shopee.com/s/AKfycbyAX4uXKHUoeBjtLdjUpo-IghIZVcN-dIQwuABI95DpoVQUBCXIILFbxJVoqClOi80g/exec"; 

document.addEventListener("DOMContentLoaded", () => {
  // 1. 初始化日期預設值 (調整為 3 天前至今日，呼應後端 3 日強制限縮機制)
  const today = new Date();
  const threeDaysAgo = new Date(today.getFullYear(), today.getMonth(), today.getDate() - 3);

  const formatDate = (dateObj) => {
    const y = dateObj.getFullYear();
    const m = String(dateObj.getMonth() + 1).padStart(2, '0');
    const d = String(dateObj.getDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
  };

  document.getElementById("startDate").value = formatDate(threeDaysAgo);
  document.getElementById("endDate").value = formatDate(today);

  // 2. 綁定按鈕點擊事件
  document.getElementById("searchBtn").addEventListener("click", fetchData);

  // 3. 頁面載入完成後自動執行首次查詢
  fetchData();
});

/**
 * 發送 API 請求向 GAS 撈取趨勢資料
 */
async function fetchData() {
  const startDate = document.getElementById("startDate").value;
  const endDate = document.getElementById("endDate").value;
  const category = document.getElementById("categorySelect").value;

  if (!startDate || !endDate) {
    alert("請選擇完整日期範圍！");
    return;
  }

  const loading = document.getElementById("loading");
  const resultContainer = document.getElementById("resultContainer");

  loading.classList.remove("hidden");
  resultContainer.classList.add("hidden");

  try {
    const queryUrl = `${GAS_WEB_APP_URL}?startDate=${startDate}&endDate=${endDate}&category=${encodeURIComponent(category)}`;
    const response = await fetch(queryUrl);

    if (!response.ok) {
      throw new Error(`HTTP 錯誤，狀態碼：${response.status}`);
    }
    const data = await response.json();

    if (data.status === "error") {
      alert("API 錯誤：" + data.message);
      return;
    }

    // 渲染 UI 資料
    renderResults(data);
  } catch (err) {
    console.error("抓取資料失敗：", err);
    alert("連線失敗，請檢查 API 部署權限是否設為「任何人 (Anyone)」，或確認網路連線！");
  } finally {
    loading.classList.add("hidden");
    resultContainer.classList.remove("hidden");
  }
}

/**
 * 核心渲染 UI 邏輯
 */
function renderResults(data) {
  // ─────────────────────────────────────────────────────────────────
  // 1. 更新總討論篇數 Badge
  // ─────────────────────────────────────────────────────────────────
  const badgeEl = document.getElementById("totalArticlesBadge");
  if (badgeEl) {
    badgeEl.textContent = `${data.totalArticles || 0} 篇討論`;
  }

  // ─────────────────────────────────────────────────────────────────
  // 2. 🏷️ 渲染熱門關鍵字 Top 5 (對應後端 keywordsRanking)
  // ─────────────────────────────────────────────────────────────────
  const keywordsList = document.getElementById("keywordsList");
  if (keywordsList) {
    keywordsList.innerHTML = "";
    const kwData = data.keywordsRanking || [];

    if (kwData.length === 0) {
      keywordsList.innerHTML = `<li style="font-size:12px; color:#94a3b8; padding:8px 0;">（區間內無顯著關鍵字）</li>`;
    } else {
      const maxKwCount = kwData[0].count || 1;
      kwData.forEach((item, index) => {
        const rank = index + 1;
        const rankClass = rank <= 3 ? `top${rank}` : "";
        const barWidth = Math.round((item.count / maxKwCount) * 100) || 0;

        const li = document.createElement("li");
        li.className = "brand-item";
        li.innerHTML = `
          <div class="brand-rank ${rankClass}">${rank}</div>
          <div class="brand-name" title="${escapeHtml(item.word)}">${escapeHtml(item.word)}</div>
          <div class="brand-bar-container">
            <div class="brand-bar" style="width: ${barWidth}%;"></div>
          </div>
          <div class="brand-count">${item.count}次</div>
        `;
        keywordsList.appendChild(li);
      });
    }
  }

  // ─────────────────────────────────────────────────────────────────
  // 3. 🔥 渲染熱門品牌 Top 5 (對應後端 top5Brands)
  // ─────────────────────────────────────────────────────────────────
  const brandList = document.getElementById("brandList");
  if (brandList) {
    brandList.innerHTML = "";
    const brandsData = data.top5Brands || [];

    if (brandsData.length === 0) {
      brandList.innerHTML = `<li style="font-size:12px; color:#94a3b8; padding:8px 0;">（區間內無品牌提及）</li>`;
    } else {
      const maxBrandCount = brandsData[0].count || 1;
      brandsData.forEach((item, index) => {
        const rank = index + 1;
        const rankClass = rank <= 3 ? `top${rank}` : "";
        const barWidth = Math.round((item.count / maxBrandCount) * 100) || 0;

        const li = document.createElement("li");
        li.className = "brand-item";
        li.innerHTML = `
          <div class="brand-rank ${rankClass}">${rank}</div>
          <div class="brand-name" title="${escapeHtml(item.brand)}">${escapeHtml(item.brand)}</div>
          <div class="brand-bar-container">
            <div class="brand-bar" style="width: ${barWidth}%;"></div>
          </div>
          <div class="brand-count">${item.count}次</div>
        `;
        brandList.appendChild(li);
      });
    }
  }

  // ─────────────────────────────────────────────────────────────────
  // 4. 🎉 渲染焦點話題摘要 (eventSummary)
  // ─────────────────────────────────────────────────────────────────
  const eventSummary = document.getElementById("eventSummary");
  if (eventSummary) {
    const rawSummary = data.eventSummary || "";

    if (!rawSummary || rawSummary === "無資料" || rawSummary === "區間內熱門品牌尚無顯著促銷或焦點活動討論" || rawSummary.includes("無討論資料")) {
      eventSummary.innerHTML = `<p class="no-data" style="font-size:13px; color:#94a3b8;">${escapeHtml(rawSummary || "區間內暫無焦點話題")}</p>`;
    } else {
      const items = rawSummary.split(/[；;]/).map(s => s.trim()).filter(Boolean);
      if (items.length > 0) {
        let html = `<ul class="topic-list" style="list-style:none; padding:0; margin:0;">`;
        items.forEach(item => {
          const match = item.match(/^\[(.*?)\]\s*(.*)$/);
          if (match) {
            const tag = escapeHtml(match[1]);
            const title = escapeHtml(match[2]);
            html += `
              <li style="margin-bottom:8px; line-height:1.4; font-size:13px;">
                <span class="topic-tag" style="background:#e0f2fe; color:#0369a1; padding:2px 6px; border-radius:4px; font-weight:bold; font-size:11px; margin-right:4px;">${tag}</span>
                <span class="topic-title" title="${title}">${title}</span>
              </li>`;
          } else {
            html += `
              <li style="margin-bottom:8px; line-height:1.4; font-size:13px;">
                <span class="topic-tag" style="background:#f1f5f9; color:#475569; padding:2px 6px; border-radius:4px; font-weight:bold; font-size:11px; margin-right:4px;">焦點</span>
                <span class="topic-title" title="${escapeHtml(item)}">${escapeHtml(item)}</span>
              </li>`;
          }
        });
        html += `</ul>`;
        eventSummary.innerHTML = html;
      } else {
        eventSummary.textContent = rawSummary;
      }
    }
  }

  // ─────────────────────────────────────────────────────────────────
  // 5. 🔗 渲染相關文章連結 (相容陣列與分區物件結構)
  // ─────────────────────────────────────────────────────────────────
  const linksList = document.getElementById("linksList");
  if (linksList) {
    linksList.innerHTML = "";

    let topLinks = [];
    let otherLinks = [];

    if (Array.isArray(data.relatedLinks)) {
      topLinks = data.relatedLinks;
    } else if (data.relatedLinks && typeof data.relatedLinks === 'object') {
      topLinks = data.relatedLinks.topBrandLinks || [];
      otherLinks = data.relatedLinks.otherLinks || [];
    }

    if (topLinks.length === 0 && otherLinks.length === 0) {
      linksList.innerHTML = `<li style="font-size:12px; color:#94a3b8; padding:8px 0;">（區間內無相關文章連結）</li>`;
    } else {
      const createLinkItem = (item, isOther = false) => {
        const li = document.createElement("li");
        li.style.marginBottom = "6px";
        if (isOther) li.style.opacity = "0.85";

        const a = document.createElement("a");
        a.href = item.url;
        a.target = "_blank";
        a.rel = "noopener noreferrer";
        a.title = item.title;
        a.textContent = `• ${item.title}`;
        a.style.textDecoration = "none";
        a.style.color = isOther ? "#4b5563" : "#2563eb";
        a.style.fontSize = "13px";

        if (item.brand) {
          const tag = document.createElement("span");
          tag.textContent = ` (${item.brand})`;
          tag.style.fontSize = "11px";
          tag.style.color = "#94a3b8";
          tag.style.marginLeft = "4px";
          a.appendChild(tag);
        }

        a.addEventListener("click", (e) => {
          e.preventDefault();
          if (typeof chrome !== "undefined" && chrome.tabs && chrome.tabs.create) {
            chrome.tabs.create({ url: item.url });
          } else {
            window.open(item.url, "_blank");
          }
        });

        li.appendChild(a);
        return li;
      };

      topLinks.forEach(item => {
        linksList.appendChild(createLinkItem(item, false));
      });

      if (otherLinks.length > 0) {
        const divider = document.createElement("li");
        divider.style.listStyle = "none";
        divider.style.marginTop = "10px";
        divider.style.marginBottom = "6px";
        divider.style.fontSize = "12px";
        divider.style.fontWeight = "bold";
        divider.style.color = "#64748b";
        divider.textContent = "📌 其他參考討論：";
        linksList.appendChild(divider);

        otherLinks.forEach(item => {
          linksList.appendChild(createLinkItem(item, true));
        });
      }
    }
  }
}

/**
 * 簡易 HTML 轉義字串防護，防止 XSS 攻擊
 */
function escapeHtml(str) {
  return String(str || '')
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}