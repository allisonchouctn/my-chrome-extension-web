// ⚠️ 已修復：改為標準通用 Google Apps Script Web App 網址格式
const GAS_WEB_APP_URL = "https://script.google.com/a/macros/shopee.com/s/AKfycbyAX4uXKHUoeBjtLdjUpo-IghIZVcN-dIQwuABI95DpoVQUBCXIILFbxJVoqClOi80g/exec";

document.addEventListener("DOMContentLoaded", () => {
  // 初始化日期為當月 1 號至今日
  const today = new Date();
  const year = today.getFullYear();
  const month = String(today.getMonth() + 1).padStart(2, '0');
  const day = String(today.getDate()).padStart(2, '0');
  document.getElementById("startDate").value = `${year}-${month}-01`;
  document.getElementById("endDate").value = `${year}-${month}-${day}`;
  
  // 綁定查詢按鈕事件
  document.getElementById("searchBtn").addEventListener("click", fetchData);
  
  // 預設一開啟外掛就自動搜尋一次
  fetchData();
});

async function fetchData() {
  const startDate = document.getElementById("startDate").value;
  const endDate = document.getElementById("endDate").value;
  const category = document.getElementById("categorySelect").value;
  
  if (!startDate || !endDate) {
    alert("請選擇完整日期範圍！");
    return;
  }
  
  // 顯示 Loading，隱藏結果
  const loading = document.getElementById("loading");
  const resultContainer = document.getElementById("resultContainer");
 
  loading.classList.remove("hidden");
  resultContainer.classList.add("hidden");
  
  try {
    const queryUrl = `${GAS_WEB_APP_URL}?startDate=${startDate}&endDate=${endDate}&category=${encodeURIComponent(category)}`;
    const response = await fetch(queryUrl);
   
    if (!response.ok) {
      throw new Error(`HTTP 錯誤，狀態碼：${response.status}`);
    }
    const data = await response.json();
    if (data.status === "error") {
      alert("API 錯誤：" + data.message);
      return;
    }
    // 渲染 UI 資料
    renderResults(data);
  } catch (err) {
    console.error("抓取資料失敗：", err);
    alert("連線失敗，請檢查 API 部署權限是否設為「任何人 (Anyone)」，或確認網路連線！");
  } finally {
    loading.classList.add("hidden");
    resultContainer.classList.remove("hidden");
  }
}

function renderResults(data) {
  // 1. 更新總討論篇數
  document.getElementById("totalArticlesBadge").textContent = `${data.totalArticles || 0} 篇討論`;
  
  // 2. 渲染 Top 5 品牌排行榜
  const brandList = document.getElementById("brandList");
  brandList.innerHTML = "";
  if (!data.top5Brands || data.top5Brands.length === 0) {
    brandList.innerHTML = `<li style="font-size:12px; color:#94a3b8; padding:8px 0;">（區間內無品牌提及）</li>`;
  } else {
    // 找出最高提及次數作為長條圖的 100% 基準
    const maxCount = data.top5Brands[0].count || 1;
    data.top5Brands.forEach((item, index) => {
      const rank = index + 1;
      const rankClass = rank <= 3 ? `top${rank}` : "";
      const barWidth = Math.round((item.count / maxCount) * 100);
      const li = document.createElement("li");
      li.className = "brand-item";
      li.innerHTML = `
        <div class="brand-rank ${rankClass}">${rank}</div>
        <div class="brand-name" title="${escapeHtml(item.brand)}">${escapeHtml(item.brand)}</div>
        <div class="brand-bar-container">
          <div class="brand-bar" style="width: ${barWidth}%;"></div>
        </div>
        <div class="brand-count">${item.count}次</div>
      `;
      brandList.appendChild(li);
    });
  }

  // 3. 渲染焦點話題摘要 (方案 C 條列風格)
  const eventSummary = document.getElementById("eventSummary");
  const rawSummary = data.eventSummary || "";

  if (!rawSummary || rawSummary === "無活動資訊") {
    eventSummary.innerHTML = `<p class="no-data">區間內暫無焦點話題</p>`;
  } else if (Array.isArray(data.focusTopics) && data.focusTopics.length > 0) {
    // 若 API 提供結構化陣列: [{ category: "情報", title: "..." }]
    let html = `<ul class="topic-list">`;
    data.focusTopics.forEach(item => {
      const cat = escapeHtml(item.category || "熱門");
      const title = escapeHtml(item.title || "");
      html += `
        <li>
          <span class="topic-tag">${cat}</span>
          <span class="topic-title" title="${title}">${title}</span>
        </li>`;
    });
    html += `</ul>`;
    eventSummary.innerHTML = html;
  } else {
    // 若 API 回傳傳統字串，自動切割分號「；」並解析 [標籤]
    const items = rawSummary.split(/[；;]/).map(s => s.trim()).filter(Boolean);
    if (items.length > 0) {
      let html = `<ul class="topic-list">`;
      items.forEach(item => {
        const match = item.match(/^\[(.*?)\]\s*(.*)$/);
        if (match) {
          const tag = escapeHtml(match[1]);
          const title = escapeHtml(match[2]);
          html += `
            <li>
              <span class="topic-tag">${tag}</span>
              <span class="topic-title" title="${title}">${title}</span>
            </li>`;
        } else {
          html += `
            <li>
              <span class="topic-tag">熱門</span>
              <span class="topic-title" title="${escapeHtml(item)}">${escapeHtml(item)}</span>
            </li>`;
        }
      });
      html += `</ul>`;
      eventSummary.innerHTML = html;
    } else {
      eventSummary.textContent = rawSummary;
    }
  }

  // 4. 渲染相關連結
  const linksList = document.getElementById("linksList");
  linksList.innerHTML = "";
  if (!data.relatedLinks || data.relatedLinks.length === 0) {
    linksList.innerHTML = `<li style="font-size:12px; color:#94a3b8; padding:8px 0;">（區間內無相關文章連結）</li>`;
  } else {
    data.relatedLinks.forEach(item => {
      const li = document.createElement("li");
      const a = document.createElement("a");
      a.href = item.url;
      a.title = item.title;
      a.textContent = `• ${item.title}`;
     
      // 相容 Chrome Extension 開啟新分頁
      a.addEventListener("click", (e) => {
        e.preventDefault();
        if (typeof chrome !== "undefined" && chrome.tabs) {
          chrome.tabs.create({ url: item.url });
        } else {
          window.open(item.url, "_blank");
        }
      });
      li.appendChild(a);
      linksList.appendChild(li);
    });
  }
}

// 簡單的 HTML 轉義以防 XSS
function escapeHtml(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}